<?php
session_start();
if (!isset($_SESSION['user_name']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_POST['answer_id'])) {
    $question = $connection->real_escape_string($_POST['question']);
    $answer = $connection->real_escape_string($_POST['answer']);

    $query = "INSERT INTO answers (question, answer) VALUES ('$question', '$answer')";
    if ($connection->query($query) === TRUE) {
        header("Location: admin_dashboard.php?status=success&message=Question added successfully.");
        exit();
    } else {
        header("Location: admin_dashboard.php?status=error&message=Error adding question: " . $connection->error);
        exit();
    }
}

$connection->close();
?>

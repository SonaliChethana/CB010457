<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Springfield - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<style>
    body {
        font-family: 'Roboto', sans-serif;
        line-height: 1.6;
        color: #333;
        background: url('Images/Paw.png') no-repeat center center/cover;
        margin: 0;
        padding: 0;
    }
    .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /*banner area*/
        .banner-container {
            background: url('Images/kids.jpg') no-repeat center center/cover;
            max-width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 50px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }

        .text-section {
        max-width: 50%;
        }

        .text-section h1 {
        font-size: 48px;
        margin-bottom: 20px;
        margin-left: 57%;
        color: #333;
        }

        .text-section p {
        font-size: 16px;
        margin-bottom: 30px;
        color: #666;
        }

        .image-section {
        position: relative;
        width: 400px;
        height: 400px;
        border-radius: 50%;
        overflow: hidden;
        animation: roll-in 2s ease-out forwards;
        }

        .image-section img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
        }

        .circle-background {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 450px;
        height: 350px;
        background-color: #FFB300;
        border-radius: 50%;
        z-index: -1;
        transform: translate(-50%, -50%);
        }

        @keyframes roll-in {
        0% {
            transform: translateX(-100vw) rotate(-360deg);
        }
        100% {
            transform: translateX(0) rotate(0deg);
        }
        }

        /*Advice section*/
        .advice-section {
            padding: 50px;
            background-color: #fff;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0px 2px 15px rgba(0,0,0,0.1);
            margin-top: 30px; /* Space above section */
        }

        .advice-section h2 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .advice-section p {
            font-size: 18px;
            margin-bottom: 20px;
            color: #555;
        }

        .advice-item {
            font-size: 18px;
            margin-bottom: 15px;
            opacity: 0; /* Start invisible */
            transform: translateY(20px); /* Start slightly lower */
            animation: fadeInUp 0.5s forwards; /* Apply animation */
        }

        /* Animation for each advice item */
        @keyframes fadeInUp {
            from {
                opacity: 0; /* Start invisible */
                transform: translateY(20px); /* Start slightly lower */
            }
            to {
                opacity: 1; /* Fully visible */
                transform: translateY(0); /* Move to original position */
            }
        }
/* Content Area */
        .content-area {
            padding: 20px;
            max-width: 65%;
            margin: 0 auto;
            animation: fadeIn 1s ease-in;
        }
        .content-area h1 {
            color: #FF5733;
            margin-bottom: 20px;
            text-align: center;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .steps {
            margin-top: 20px;
        }

        .step {
            background: #ffd1a3;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            transition: transform 0.3s;
        }

        .step:hover {
            transform: translateY(-5px);
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
        }

        .steps .step h2 {
            color: #2c3e50;
            margin: 0;
            font-size: 1.2em;
        }
        h2 {
            color: #FF5733;
            padding: 10px;
            margin: 10px 20px;
        }

        .images-container {
            display: flex;
            justify-content: space-around;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .image-box {
            width: 22%;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            margin: 10px;
            position: relative;
        }

        .image-box img {
            width: 100%;
            height: 200px; /* Fixed height */
            object-fit: cover; /* Maintain aspect ratio and cover the box */
            display: block;
        }

        .pet-type {
            position: absolute;
            bottom: 10px;
            left: 10px;
            background-color: rgba(255, 255, 255, 0.7);
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
            color: #2c3e50;
        }

        .image-box:hover {
            transform: scale(1.05);
        }
      
      
        /*cats*/
        $first:   #abe7db;
        $second:  #f67c61;
        $third:   #fff9e8;
        $forth:   #58a5a3;
        $fifth:   #172535;

        $list: ('1': $first, '2': $second,'3': $third,'4': $forth,'5': $fifth);

        @mixin grid($column-start, $column-end, $row-start: $column-start, $row-end: $column-end) {
        grid-column-start: $column-start;
        grid-column-end: $column-end;
        grid-row-start: $row-start;
        grid-row-end: $row-end;
        }

        body, html {
        margin: 0;
        padding: 0;
        }

        .cats {
        display: grid;
        grid-auto-flow: dense;
        overflow: hidden; 
        }
        @media screen and (min-width: 45em) {
        .cats {
            height: 100vh;
            grid-template-columns: 29% 29% 43.5%;
            grid-template-rows: 50% 16% 34%;
        }
        }
        @media screen and (max-width: 45em) and (min-width: 25em) {
        .cats { 
            grid-template-columns: repeat(2, (100vw / 2));
            grid-template-rows: repeat(3, 1fr);
        }
        }
        @media screen and (max-width: 25em) {
        .cats { 
            grid-template-columns: 100vw;
            grid-template-rows: repeat(5, 1fr);
        }
        }

        .cat {
        img {width:100%;}
        @each $i in map-keys($list) {
            &.cat--#{$i} {
            background-color: map-get($list, $i);
            }
        }
        &.cat--1 {
            @include grid(1, 3);
        }
        &.cat--2 {
            @include grid(1, 2, 3, 4);
        }
        &.cat--3 {
            @include grid(2, 3, 3, 4);
        }
        &.cat--4 {
            @include grid(3, 4, 1, 2);
        }
        &.cat--5 {
            @include grid(3, 4, 2, 4);
        }
        @media screen and (max-width: 45em) and (min-width: 25em) {
            @for $j from 4 through 5 {
            &.cat--#{$j} {
                @include grid($j - 3, $j - 2, 4, 5);
            }
            }
        }
        @media screen and (max-width: 25em) {
            @for $k from 1 through 5 {
            &.cat--#{$k} {
                @include grid(1, 2, $k, $k + 1);
            }
            }
        }
        }

        /*footer*/
        footer {
            text-align: center;
            padding: 20px 40px;
            background-color: #333;
            color: #FFFFFF;
            border-top: 4px solid #eb9b4b;
            
        }
</style>
<body>
    <?php if (isset($_GET['status']) && isset($_GET['message'])): ?>
        <script>
            alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>
    <header>
    <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
    </div>
    <nav>
    	<ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="KIds.php">For Kids</a></li>
                <li><a href="help.php">Help</a></li>
                <li><a href="dashboard.php">My Dashboard</a></li>
                <li><a href="edit_user.php">Edit Profile</a></li>
                <li>
                <?php
                
                if ($_SESSION['is_admin'] == 1){
                	echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                }?>
                </li>
                
              
        </ul>
        <div class="auth-buttons">
             	<a href="logout.php" class="btn">Logout</a>
        </div>
    </nav>
    </header>
     <!--banner area-->
     <div class="banner-container">
            <div class="text-section">
                <h1>Guidelines & Understanding Our Adoption Rules</h1>
               
            </div>
            <div class="image-section">
                <div class="circle-background"></div>
                <img src="Images/kidsbanner.png" alt="Dog Image">
            </div>
        </div>

        <!-- Advice Section -->
<div class="advice-section">
    <h2>How to Care for Your Pets</h2>
    <p>Here are some tips for kids on how to take care of their furry friends:</p>
    <ul style="list-style-type:none;">
        <li class="advice-item">🐶 <strong>Feed Them Regularly</strong> - Make sure to provide fresh food and water daily.</li>
        <li class="advice-item">🐱 <strong>Playtime is Important</strong> - Spend time playing with your pet to keep them happy and healthy.</li>
        <li class="advice-item">🐾 <strong>Regular Vet Visits</strong> - Take your pet to the vet for check-ups and vaccinations.</li>
        <li class="advice-item">🐕 <strong>Grooming</strong> - Brush your pet's fur regularly to keep it clean and free of tangles.</li>
        <li class="advice-item">❤️ <strong>Love and Attention</strong> - Give your pets lots of love and attention!</li>
    </ul>
</div>
 <!-- Content Area -->
 <div class="content-area">
            <h1>Adoption Rules and Steps</h1>
            <p>At Springfield Pet Rescue, we want to ensure a safe and loving environment for all our pets. Here are the steps and rules you need to follow for a successful adoption:</p>

            <div class="steps">
                <div class="step">
                    <h2>Step 1: Research</h2>
                    <p>Understand the responsibilities of pet ownership and research the type of pet that best fits your lifestyle.</p>
                </div>
                <div class="step">
                    <h2>Step 2: Visit Us</h2>
                    <p>Come to our shelter to meet the pets available for adoption. Spend time with them to find the right match.</p>
                </div>
                <div class="step">
                    <h2>Step 3: Fill Out an Application</h2>
                    <p>Complete an adoption application form, providing details about your living situation, experience with pets, and preferences.</p>
                </div>
                <div class="step">
                    <h2>Step 4: Home Check</h2>
                    <p>We will conduct a home check to ensure a suitable environment for the pet you wish to adopt.</p>
                </div>
                <div class="step">
                    <h2>Step 5: Adoption Fee</h2>
                    <p>Pay the adoption fee, which helps us cover the cost of care and veterinary services for our animals.</p>
                </div>
                <div class="step">
                    <h2>Step 6: Finalizing Adoption</h2>
                    <p>Once everything is approved, you can bring your new pet home! We’ll provide resources and support for a smooth transition.</p>
                </div>
            </div>
        </div>
    
        <!-- Relevant Images -->
        <h2>Meet Our Pets Ready for Adoption!</h2>
        <div class="images-container">
            <a href="Available.html#dogs" class="image-box">
                <img src="Images/behaviour.jpg" alt="Adoptable Dog">
                <div class="pet-type">Dog</div>
            </a>
            <a href="Available.html#cats" class="image-box">
                <img src="Images/Mittens.jpg" alt="Adoptable Cat">
                <div class="pet-type">Cat</div>
            </a>
            <a href="Available.html#rabbits" class="image-box">
                <img src="Images/inster4.jpg" alt="Adoptable Rabbit">
                <div class="pet-type">Rabbit</div>
            </a>
            <a href="Available.html#birds" class="image-box">
                <img src="Images/Peaches.jpg" alt="Adoptable Bird">
                <div class="pet-type">Bird</div>
            </a>
        </div>
        
    </div>


        <!--cats-->
        <div class="cats">
            <div class="cat cat--1">
                <img src="https://cdn.dribbble.com/users/218750/screenshots/2090988/sleeping_beauty.gif" alt="">
            </div>
            <div class="cat cat--2">
                <img src="https://cdn.dribbble.com/users/6191/screenshots/1192777/catpurr.gif" alt="">
            </div>
            <div class="cat cat--3">
                <img src="https://cdn.dribbble.com/users/6191/screenshots/2211315/meal.gif" alt="">
            </div>
            <div class="cat cat--4">
                <img src="https://cdn.dribbble.com/users/6191/screenshots/1189704/walkingcat.gif" alt="">
            </div>
            <div class="cat cat--5">
                <img src="https://cdn.dribbble.com/users/6191/screenshots/3661586/cat_sleep_dribbble.gif" alt="">
            </div>
            </div>
            <footer>
       <p>&copy;2021 Springfield Pet Rescue. All rights reserved.
       </footer>

</body>
</html>
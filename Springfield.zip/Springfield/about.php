<?php
session_start();


$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if the form is submitted for questions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_question'])) {
    $name = $connection->real_escape_string($_POST['name']);
    $email = $connection->real_escape_string($_POST['email']);
    $question = $connection->real_escape_string($_POST['question']);
    
    // Insert the question into the database
    $sql = "INSERT INTO questions (name, email, question) VALUES ('$name', '$email', '$question')";
     // Store the success message in the session to trigger the popup
     $_SESSION['success_message'] = "Your question has been submitted!";
    } else {
        echo "<p>Error: " . $sql . "<br>" . $connection->error . "</p>";
    }




// Handle answer submission
if (isset($_POST['submit_answer'])) {
    $question_id = $_POST['question_id'];
    $answer = $connection->real_escape_string($_POST['answer']);

    // Insert the answer into the database
    $answer_sql = "INSERT INTO answers (id, answer, answer_date) VALUES ('$question_id', '$answer', NOW())";
    if ($connection->query($answer_sql) === TRUE) {
        echo "Answer submitted successfully!";
        // Refresh the page to show the new answer
        echo "<meta http-equiv='refresh' content='0'>";
    } else {
        echo "Error: " . $answer_sql . "<br>" . $connection->error;
    }
}
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>springfield - About Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;  
    }
    main{
        flex-grow:1;
        }


        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');
        body {
            font-family: 'Montserrat', sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .body-container {
            width: 100%;
        }
            .image-section {
            flex: 1;
            background: url('images/ContactUs.jpg') no-repeat center center;
            background-size: cover;
            height: 600px;
        }
        /* Animation section styles */
        .welcome-hero {
            position: relative;
            height: 300px;
        }

        .welcome-hero img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .hero-text {
            position: absolute;
            top: 50%;
            left: 30%;
            transform: translate(-50%, -50%);
            text-align: center;
            font-size: 1.4em; 
            font-family: cursive;
            color: #5f513e;
            background-color: rgba(255, 255, 255, 0.7);
        }

        .hero-text h1 {
            font-size: 2.7em;
            margin: 0;
            color: #5f513e;
        }

        .hero-text p {
            font-size: 1.2em;
        }

        /* How to reach */
        .contact-section {
            text-align: center;
            padding: 50px 20px;
            background-color: #e6e6e6;
        }
        .contact-section h2 {
            font-size: 2em;
            margin-bottom: 40px;
            color: #333;
        }
        .contact-items {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }
        .contact-item {
            margin: 10px;
            flex: 1;
            min-width: 200px;
            max-width: 300px;
        }
        .contact-item i {
            font-size: 2.5em;
            color: #7cc42e;
            margin-bottom: 15px;
        }
        .contact-item h3 {
            font-size: 1.2em;
            margin-bottom: 10px;
            color: #333;
        }
        .contact-item p {
            color: #666;
            margin-bottom: 10px;
        }
        .instagram-section {
            text-align: center;
            padding: 50px 20px;
            background-color: #f8c68e;
        }
        .instagram-section h2 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #333;
        }
        .instagram-section img {
            width: 100%;
            max-width: 200px;
            height: auto;
            margin: 10px;
            border-radius: 10px;
        }
        .instagram-images {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* contact us */
        .content-section {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 50px 20px;
            background-color: #f2f2f2;
            color: #333;
        }

        .content-section img {
            width: 300px;
            height: auto;
            margin-right: 30px;
            border-radius: 10px;
        }
        .info {
            text-align: left;
            max-width: 500px;
        }
        .info h2 {
            font-size: 38px;
            margin-bottom: 20px;
        }

        .info p {
            font-size: 16px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form input[type="text"],
        form input[type="email"] {
            padding: 10px;
            width: 300px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }

        form button {
            padding: 10px;
            border: none;
            background-color: #000;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            width: 100px;
            align-self: flex-start;
        }

        form button:hover {
            background-color: #333;
        }

        /*Answer Section*/
        .question-section {
            width: 100%;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffc787; /* Light gray background */
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        }

        .question-section h2 {
            text-align: center;
            color: #2c3e50; /* Darker blue-gray for header */
            font-size: 2rem;
            margin-bottom: 30px;
            font-weight: 700;
        }

        /* Individual question item */
        .question-item {
            padding: 15px;
            background-color: #ffffff; /* White background for each question */
            border: 1px solid #e0e0e0; /* Light gray border */
            border-radius: 8px;
            margin-bottom: 20px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .question-item:hover {
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        .question-item h3 {
            font-size: 1.2rem;
            color: #3498db; /* Blue for the question author */
            margin-bottom: 10px;
        }

        .question-item p {
            font-size: 1rem;
            color: #34495e; /* Dark gray for the question text */
            margin-bottom: 10px;
        }

        /* Answer Styling */
        .question-item .answer {
            background-color: #ecf0f1; /* Light gray background for the answer */
            padding: 10px;
            border-left: 4px solid #2ecc71; /* Green border for answer */
            border-radius: 5px;
            margin-top: 10px;
            font-size: 1rem;
            color: #2c3e50;
        }

        .question-item .answer strong {
            color: #27ae60; /* Stronger green for the "Answer:" label */
        }

        .question-item em {
            font-size: 0.9rem;
            color: #7f8c8d; /* Light gray italic for dates */
        }

        /* Answer form for admin */
        .question-item form {
            margin-top: 20px;
        }

        .question-item textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #bdc3c7; /* Light border */
            resize: vertical;
            font-size: 1rem;
            font-family: 'Arial', sans-serif;
        }

        .question-item button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #27ae60; /* Green for submit button */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .question-item button:hover {
            background-color: #2ecc71; /* Slightly lighter green on hover */
        }
        

         /* Popup Styles */
         #successPopup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 1000;
        }

        #popupOverlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .popup-close-btn {
            background-color: #fff;
            color: #4CAF50;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        /* Footer Styles */
        .footer {
            background: #333;
            color: #fff;
            padding: 30px 0;
            text-align: center;
        }
        
        .footer .footer-container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        }
        
        .footer .footer-container div {
        flex: 1;
        padding: 10px;
        }
        
        .footer h3 {
        margin-bottom: 20px;
        }
        
        .footer ul {
        list-style: none;
        padding: 0;
        }
        
        .footer ul li {
        margin-bottom: 10px;
        }
        
        .footer ul li a {
        color: #fff;
        text-decoration: none;
        }
        
        .footer ul li a:hover {
        text-decoration: underline;
        }
        
        .social-icons {
        display: flex;
        gap: 10px;
        }
        
        .social-icons a {
        font-size: 24px;
        color: #333;
        text-decoration: none;
        }
        
        .social-icons a:hover {
        color: #0077b5; /* Change color on hover */
        }
        
        .footer-bottom {
        margin-top: 20px;
        border-top: 1px solid #555;
        padding-top: 10px;
        }

                
</style>
<body>
    <header>
       <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
        </div>
        <nav>
            <ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="help.php">Help</a></li>
                <li>
                 <?php if (isset($_SESSION['user_name'])){ 
                 	echo '<a href="dashboard.php">My Dashboard</a>';
                 }?>	
                </li>
                <li>
                 <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                    echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                 } ?>
                </li>
               
            </ul>
            <div class="auth-buttons">
                <?php if (isset($_SESSION['user_name'])): ?>
                    <a href="logout.php" class="btn">Logout</a>
                <?php else: ?>
                    <a href="register.php" class="btn">Register</a>
                    <a href="login.php" class="btn">Log In</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
     <!-- Popup Overlay and Success Message Popup -->
     <div id="popupOverlay"></div>
    <div id="successPopup">
        <p>Your question has been submitted successfully!</p>
        <button class="popup-close-btn" onclick="closePopup()">Close</button>
    </div>

 <!-- Animation Section -->
 <div class="welcome-hero">
                <img src="images/Homebanner.jpg" alt="Home Banner 1">
                <div class="hero-text">
                    <h1>Springfield Pet Rescue</h1>
                    <p>Rescuing and rehoming pets in the Western Province of Sri Lanka</p>
                </div>
            </div>            
        <!-- End Animation Section -->

        <!-- How to Reach Us Section -->
    <div class="contact-section">
        <h2>How to reach us</h2>
        <div class="contact-items">
            <div class="contact-item">
                <i class="fas fa-home"></i>
                <h3>Address</h3>
                <p>123 Springfield Road, Western Province, Sri Lanka</p>
                <p>info@springfieldpetrescue.org</p>
                <p>+94 756 456 695</p>
            </div>
            <div class="contact-item">
                <i class="fas fa-clock"></i>
                <h3>Opening Hours</h3>
                <p>9:00 - 17:00</p>
            </div>
            <div class="contact-item">
                <i class="fas fa-heart"></i>
                <h3>Social</h3>
                <p>Follow us on our social pages and get to know more.</p>
            </div>
        </div>
    </div>

    <!-- Follow Us on Instagram Section -->
    <div class="instagram-section">
        <h2>Photos :</h2>
        <div class="instagram-images">
            <img src="Images/Inster1.jpg" alt="Pet Image 1">
            <img src="Images/inster2.png" alt="Pet Image 2">
            <img src="Images/inster3.jpg" alt="Pet Image 3">
            <img src="Images/inster4.jpg" alt="Pet Image 4">
        </div>
    </div>
         
    <div class="content-section">
    <img src="Images/Sweetd2.png" alt="Puppy">
    <div class="info">
        <h2>Need a Sweet Heart?</h2>
        <p>Give a loving home, and you'll find a loyal heart—adopt a pet and change both your lives forever.</p>
        <p>Want more information? <b>Contact US 👇</b></p>
        <form method="POST" action="">
            <input type="text" name="name" placeholder="Enter your Name" required>
            <input type="email" name="email" placeholder="Enter your Email" required>
            <input type="text" name="question" placeholder="Enter your question" required>
            <button type="submit" name="submit_question">Submit</button>
        </form>
    </div>
</div>

     <!-- Question Section: Display all questions and answers -->
<div class="question-section">
    <?php
    // Retrieve all questions from the database
    $sql = "SELECT * FROM questions";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        // Only display the title and questions if there are questions
        echo "<h2>Questions & Answers</h2>";
        while ($row = $result->fetch_assoc()) {
            $id = $row['id'];
            $name = $row['name'];
            $question = $row['question'];
            $submission_date = $row['submission_date'];

            echo "<div class='question-item'>";
            echo "<h3>$name asked on $submission_date</h3>";
            echo "<p>Question: $question</p>";

            // Fetch any answers to this question
            $answer_sql = "SELECT * FROM answers WHERE id = $id";
            $answer_result = $connection->query($answer_sql);
            
            if ($answer_result->num_rows > 0) {
                while ($answer_row = $answer_result->fetch_assoc()) {
                    $answer = $answer_row['answer'];
                    $answer_date = $answer_row['answer_date'];
                    echo "<p><strong>Answer:</strong> $answer <em>(answered on $answer_date)</em></p>";
                }
            } else {
                echo "<p><em>No answer yet</em></p>";
            }

            // Display form to submit an answer (only if user is admin)
            if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                echo "
                <form method='POST' action=''>
                    <textarea name='answer' placeholder='Enter your answer here' required></textarea>
                    <input type='hidden' name='question_id' value='$id'>
                    <button type='submit' name='submit_answer'>Submit Answer</button>
                </form>";
            }

            echo "</div><hr>";
        }
    }
    ?>
</div>

        </main>

		   <!-- Footer Start -->
		   <footer class="footer">
			<div class="footer-container">
				<div>
					<h3>Quick Links</h3>					
				</div>
				<div>
					<h3>Contact Us</h3>
					<ul>
						<li>Email: info@springfieldpetrescue.org</li>
						<li>Phone: +1 234 567 890</li>
						<li>Address: 123 Springfield Road, Western Province, Sri Lanka</li>
					</ul>
				</div>
				<div>
					<h3>Follow Us</h3>
					<div class="social-icons">
						<a href="https://www.facebook.com" target="_blank" class="fab fa-facebook"></a>
						<a href="https://www.twitter.com" target="_blank" class="fab fa-twitter"></a>
						<a href="https://www.instagram.com" target="_blank" class="fab fa-instagram"></a>
						<a href="https://www.linkedin.com" target="_blank" class="fab fa-linkedin"></a>
					</div>
					
				</div>
			</div>
			<div class="footer-bottom">
				© 2021 Springfield Pet Rescue. All rights reserved.
			</div>
		</footer>
		<!-- Footer End -->

    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Include Owl Carousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
        
     <!-- JavaScript -->
     <script>
        // Function to show the popup
        function showPopup() {
            document.getElementById("popupOverlay").style.display = "block";
            document.getElementById("successPopup").style.display = "block";
        }

        // Function to close the popup
        function closePopup() {
            document.getElementById("popupOverlay").style.display = "none";
            document.getElementById("successPopup").style.display = "none";
        }

        // Check if the session success message exists and show the popup
        <?php if (isset($_SESSION['success_message'])): ?>
            window.onload = function() {
                showPopup();
            };
            <?php unset($_SESSION['success_message']); // Clear the session message ?>
        <?php endif; ?>
    </script>
</body>
</html>
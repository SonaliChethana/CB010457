<?php
session_start();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWS - Contact Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;  
  }
  main{
        flex-grow:1;
        }


        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
    
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');
    body {
        font-family: 'Montserrat', sans-serif;
        color: #333;
        margin: 0;
        padding: 0;
    }

    .body-container {
        width: 100%;
    }
            .welcome-hero {
                background: url('Images/What.jpg') no-repeat center center;
                background-size: cover;
                padding: 100px 0;
                color: #5f513e;
                text-align: left;
            } 
            .availabilities {
            background: url('Images/Availability.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
            padding: 20px;
            text-align: right; 
            }
            .about {
            padding: 30px 80px;
            margin: 50px;
            background: url('Images/transparent.png') no-repeat;
            background-color: aliceblue;
            background-size: cover;
        }
    /* Welcome Hero Section */
    .welcome-hero .header-text {
    max-width: 600px;
    margin: 10px 40px;
    text-align: left;
    }

    .welcome-hero .container{
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        padding: 10px 0;
    }
    .welcome-hero h2 {
    font-size: 4.5em;
    font-weight: 700;
    line-height: 1.4;
    margin-bottom: 20px;
    font-family: cursive;
    text-align: left;
    }
    
    .welcome-hero h2 span {
    color: #f18c28;
    }
    
    .welcome-hero p {
    font-size: 1em;
    line-height: 1.6;
    margin-bottom: 30px;
    }  

    /* About Section */

    .section-heading {
    margin-bottom: 50px;
    }

    .section-heading h2 {
    font-size: 36px;
    font-weight: 700;
    text-align: center;
    color: #333;
    position: relative;
    display: inline-block;
    padding-bottom: 10px;
    width: 100%;
    }

    .section-heading h2::after {
    content: '';
    width: 50px;
    height: 3px;
    background-color: #27ae60;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    }

    .about-content {
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    }

    .about-txt {
    flex: 0 0 60%;
    margin-bottom: 30px;
    text-align: center;
    }

    .about-txt h3 {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px;
    text-align: center;
    }

    .about-txt p {
    font-size: 16px;
    line-height: 1.6;
    color: #555;
    margin-bottom: 30px;
    }

    /* what we do section */
    .what-we-do-section {
        display: flex;
        flex-wrap: wrap;
        padding: 10px;
        justify-content: space-between;
        background-color: #f8c68e;
    }
    .left-image {
        flex: 1;
        min-width: 300px;
    }
    .left-image img {
        width: 100%;
        height: auto;
    }
    .right-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
    }
    .right-content img:first-child {
        width: 50%;
        height: auto;
        border-radius: 60%; /* Circular shape for the first image */
        margin-bottom: 10px;
    }
    .right-content img:not(:first-child) {
        width: 100%;
        height: auto;
        margin-bottom: 10px;
    }
    .text-overlay {
        position: relative;
        color: #fff;
        text-align: center;
        background: rgba(0, 0, 0, 0.4);
        padding: 20px;
        border-radius: 10px;
        margin-top: -50px;
        z-index: 1;
    }
    .text-overlay h2 {
        font-size: 2.5em;
        margin: 0;
    }
    .text-overlay p {
        font-size: 1em;
        margin: 10px 0 0;
    }
    .programs {
        display: flex;
        flex-wrap: wrap;
        padding: 20px;
        justify-content: space-between;
        margin-top: 50px;
    }

    .program-item {
        width: 48%; /* Two items per row */
        background-color: #f9f9f9;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .program-item:hover {
        transform: translateY(-10px);
        box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.2);
    }

    .program-item h3 {
        font-size: 1.5em;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        color: #333;
    }

    .program-item h3 i {
        font-size: 1.5em;
        margin-right: 10px;
        color: #7cc42e;
    }

    .program-item p {
        color: #666;
    }

    .read-more {
        color: #0066cc;
        cursor: pointer;
        font-weight: bold;
        display: inline-block;
        margin-top: 10px;
        transition: color 0.3s ease;
    }

    .read-more:hover {
        color: #004499;
    }

    /* Popup styles */
    .popup {
        display: none;
        position: fixed;
        z-index: 100;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.7);
        padding-top: 60px;
    }

    .popup-content {
        background-color: #fff;
        margin: 5% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        border-radius: 10px;
        position: relative;
    }

    .popup-content img {
        max-width: 100%;
        margin-bottom: 20px;
        border-radius: 10px;
    }

    .close {
        position: absolute;
        top: 10px;
        right: 20px;
        color: #aaa;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: #000;
    }
    /* program section ends here */


    /*Availabilities section */

    .availabilities h2 {
        text-align: center;
        margin-bottom: 20px;
        font-size: 2.5em;
        font-family: cursive;
    }
    .availabilities-content {
        align-items: right;
        opacity: 0.8;
    }

    .availabilities-item {
        margin: 10px 0;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 50%;
    }

    .availabilities-item h3 {
        color: #333;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
    }

    .availabilities-item h3 i {
        margin-right: 10px;
    }

    .item-details {
        display: flex;
        flex-direction: column;
    }

    .item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }

    .item i {
        font-size: 1.2em;
        color: #333;
        margin-right: 10px;
    }

    .item span {
        color: #666;
    }


    /* Footer styles */
    .footer {
        background-color: #333;
        color: #fff;
        padding: 20px 0;
        text-align: center;
    }
    .footer .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
    }
    .footer .container .social-icons {
        list-style: none;
        padding: 0;
    }
    .footer .container .social-icons li {
        display: inline;
        margin-right: 10px;
    }
    .footer .container .social-icons li a {
        color: #fff;
        text-decoration: none;
        font-size: 1.2em;
    }

    </style>
</head>
<body>
    <header>
       <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
        </div>
        <nav>
            <ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What We Do</a></li>
                <li><a href="help.php">Help</a></li>
                <li>
                 <?php if (isset($_SESSION['user_name'])){ 
                 	echo '<a href="dashboard.php">My Dashboard</a>';
                 }?>	
                </li>
                <li>
                 <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                    echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                 } ?>
                </li>
               
            </ul>
            <div class="auth-buttons">
                <?php if (isset($_SESSION['user_name'])): ?>
                    <a href="logout.php" class="btn">Logout</a>
                <?php else: ?>
                    <a href="register.php" class="btn">Register</a>
                    <a href="login.php" class="btn">Log In</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
   <!--welcome-hero start -->
		<section id="welcome-hero" class="welcome-hero">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="header-text">
							<h2>How We Make a Difference</h2>
							<p>Join us in making a difference in the lives of stray dogs through rescue, rehabilitation, and rehoming.</p>
						</div>
					</div>
				</div>
			</div>
        </section>
		<!--welcome-hero end -->

        	 <!-- About Section -->
		 <section class="about" id="about">
            <div class="container">
                <div class="section-heading">
                    <h2>What we do</h2>
                </div>
                <div class="about-content">
                    <div class="about-txt">
                        <h3>Empowering Pet Guardians</h3>
                        <p>At Springfield Pet Rescue, our mission goes beyond rescuing animals. We are committed to empowering pet guardians with the knowledge and skills needed to train, care for, and foster pets. Whether you’re a first-time pet owner or an experienced foster, we provide resources and support to help you understand animal behavior, train pets effectively, and offer temporary care. Our goal is to create a compassionate community where every pet receives the love and care they deserve, and every guardian feels equipped to contribute to a better environment for all animals. Join us in making a lasting impact on the lives of pets and people alike.</p>
                    </div>
                </div>
            </div>
        </section>

                   <!-- What We Do Section -->
        <section class="what-we-do-section">
            <!-- Left Image -->
            <div class="left-image">
                <img src="Images/sleeppet.jpeg" alt="Pet Love Image">
                <div class="text-overlay">
                    <h2>Pet Love</h2>
                    <p>Since newly abandoned pups are competing with each other for human heartstrings, evolution says they should be most adorable around 6 and 11 weeks.</p>
                </div>
            </div>

            <!-- Right Content -->
            <div class="right-content">
                <img src="Images/Puppt2.jpg" alt="Waiting for You Image">
                <img src="Images/WhatWedo.jpg" alt="Pet Care Image">
            </div>
        </section>

        <!-- Programs Section -->
        <section class="programs">
            <div class="program-item">
                <h3><i class="fas fa-dog"></i>Dog Training</h3>
                <p>Dogs which are trained with rewards enjoy learning - they are a partner in the training sessions and often 'offer' new behaviours to see if they get...</p>
                <span class="read-more" data-target="popup1">Read More</span>
            </div>
            <div class="program-item">
                <h3><i class="fas fa-home"></i>House-Training</h3>
                <p>All dogs can be taught to toilet outdoors, but this is not something most will learn on their own; we must show them the right thing...</p>
                <span class="read-more" data-target="popup2">Read More</span>
            </div>
            <div class="program-item">
                <h3><i class="fas fa-hand-holding-heart"></i>Temporary Care</h3>
                <p>Providing temporary care for animals can be a lifeline for pets in need. Our program focuses on giving pets a safe place...</p>
                <span class="read-more" data-target="popup3">Read More</span>
            </div>
            <div class="program-item">
                <h3><i class="fas fa-paw"></i>Dog's Behaviour</h3>
                <p>Understanding your dog’s behavior is key to ensuring their happiness and well-being. Our behavioral programs are designed...</p>
                <span class="read-more" data-target="popup4">Read More</span>
            </div>
        </section>
        <!-- End Programs Section -->

        <!-- Popup Modals -->
        <div id="popup1" class="popup">
            <div class="popup-content">
                <span class="close">&times;</span>
                <img src="Images/Dogtrain.jpeg" alt="Dog Training">
                <h3>Dog Training</h3>
                <p>Our dog training programs are designed to foster better relationships between dogs and their owners. We focus on positive reinforcement techniques that help dogs learn in a fun and supportive environment. Whether it's basic obedience, advanced training, or specialized skills, our programs cater to all levels.</p>
            </div>
        </div>

        <div id="popup2" class="popup">
            <div class="popup-content">
                <span class="close">&times;</span>
                <img src="Images/hometrain.jpeg" alt="House Training">
                <h3>House-Training</h3>
                <p>House-training is essential for a happy home. We provide structured programs that guide pet owners in teaching their dogs the right habits for indoor living. Consistency, patience, and positive reinforcement are key elements in our approach.</p>
            </div>
        </div>

        <div id="popup3" class="popup">
            <div class="popup-content">
                <span class="close">&times;</span>
                <img src="Images/placespet.jpg" alt="Temporary Care">
                <h3>Temporary Care</h3>
                <p>Providing temporary care for animals in need is at the heart of our mission. We offer support and resources for pet owners who are going through tough times, ensuring that their pets are cared for while they get back on their feet. Our foster program also provides a safe haven for pets awaiting adoption.</p>
            </div>
        </div>

        <div id="popup4" class="popup">
            <div class="popup-content">
                <span class="close">&times;</span>
                <img src="Images/behaviour.jpg" alt="Dog's Behaviour">
                <h3>Dog's Behaviour</h3>
                <p>Understanding your dog’s behavior is key to ensuring their happiness and well-being. Our behavioral programs are designed to help owners better understand their dogs' needs, and address common behavioral issues such as aggression, anxiety, and separation distress. We provide tools and guidance to build a strong bond between pets and their owners.</p>
            </div>
        </div>

        <script>
            // JavaScript for handling the popup
            document.querySelectorAll('.read-more').forEach(function(button) {
                button.addEventListener('click', function() {
                    var popupId = this.getAttribute('data-target');
                    document.getElementById(popupId).style.display = 'block';
                });
            });

            document.querySelectorAll('.close').forEach(function(button) {
                button.addEventListener('click', function() {
                    this.closest('.popup').style.display = 'none';
                });
            });

            window.onclick = function(event) {
                if (event.target.classList.contains('popup')) {
                    event.target.style.display = 'none';
                }
            };
        </script>

       
    <!-- Availabilities Section -->
    <div class="availabilities">
        <h2>Availabilities in Sri Lanka</h2>
        <div class="availabilities-content">
            <div class="availabilities-item">
                <h3><i class="fas fa-shelter"></i> Temporary Pet Care Places</h3>
                <div class="item-details">
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Happy Paws Shelter - Colombo</span>
                    </div>
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Safe Haven Rescue - Kandy</span>
                    </div>
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Furry Friends Sanctuary - Galle</span>
                    </div>
                </div>
            </div>
            <div class="availabilities-item">
                <h3><i class="fas fa-school"></i> Pet Training Centers</h3>
                <div class="item-details">
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Pawsitive Training Academy - Colombo</span>
                    </div>
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Good Dog Training Center - Negombo</span>
                    </div>
                    <div class="item">
                        <i class="fas fa-paw"></i>
                        <span>Happy Tails Training School - Jaffna</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Availabilities Section -->
   
    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Springfield Pet Rescue. All Rights Reserved.</p>
            <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
            </ul>
        </div>
    </footer>
  
</body>
</html>


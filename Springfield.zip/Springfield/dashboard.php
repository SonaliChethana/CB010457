<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$user_name = $_SESSION['user_name'];


$pet_sql = "SELECT pet_id, name, pet_type, age, gender, district, city, description, photo, is_adopted FROM pet WHERE user_name=?";
$pet_stmt = $connection->prepare($pet_sql);
$pet_stmt->bind_param("s", $user_name);
$pet_stmt->execute();
$pet_result = $pet_stmt->get_result();


$adopt_sql = "SELECT adopt.adopt_id, adopt.pet_id, pet.name AS pet_name, adopt.full_name, adopt.district, adopt.city, adopt.phone_number
              FROM adopt
              JOIN pet ON adopt.pet_id = pet.pet_id
              WHERE pet.user_name = ? AND adopt.is_confirmed = 0";
$adopt_stmt = $connection->prepare($adopt_sql);
$adopt_stmt->bind_param("s", $user_name);
$adopt_stmt->execute();
$adopt_result = $adopt_stmt->get_result();


$confirmed_adopt_sql = "SELECT adopt.adopt_id, adopt.pet_id, pet.name AS pet_name, adopt.full_name, adopt.district, adopt.city, adopt.phone_number
                        FROM adopt
                        JOIN pet ON adopt.pet_id = pet.pet_id
                        WHERE adopt.is_confirmed = 1 AND pet.user_name = ?";
$confirmed_adopt_stmt = $connection->prepare($confirmed_adopt_sql);
$confirmed_adopt_stmt->bind_param("s", $user_name);
$confirmed_adopt_stmt->execute();
$confirmed_adopt_result = $confirmed_adopt_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Springfield - Dashboard</title>
</head>
<style>
    body {
        font-family: 'Roboto', sans-serif;
        line-height: 1.6;
        color: #333;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

    .main-container {
        width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }


    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .page-title {
        font-size: 2rem;
        color: #2c3e50;
    }

    .section-title {
        font-size: 1.5rem;
        color: #2c3e50;
        margin-top: 30px;
        margin-bottom: 15px;
    }


    .btn-primary, .btn-secondary, .btn-danger, .btn-confirm, .btn-delete {
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        color: #fff;
        text-decoration: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .btn-primary {
        background-color: #3498db;
    }

    .btn-secondary {
        background-color: #2ecc71;
    }

    .btn-danger, .btn-delete {
        background-color: #e74c3c;
    }

    .btn-confirm {
        background-color: #f39c12;
    }

    .btn-primary:hover, .btn-secondary:hover, .btn-danger:hover, .btn-confirm:hover, .btn-delete:hover {
        opacity: 0.8;
    }


    .pet-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
    }

    .pet-card {
        background-color: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .pet-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }

    .pet-details {
        padding: 15px;
    }

    .pet-actions {
        display: flex;
        justify-content: flex-end;
        margin-top: 10px;
    }

    .pet-actions a {
        margin-left: 10px;
    }


    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .data-table th,
    .data-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .data-table th {
        background: url("images/orange.jpg");
        color: #fff;
    }

    .data-table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .data-table tr:hover {
        background-color: #e0e0e0;
    }


    @media (max-width: 768px) {
        .header {
            flex-direction: column;
            align-items: flex-start;
        }

        .page-title {
            margin-bottom: 10px;
        }

        .pet-grid {
            grid-template-columns: 1fr;
        }

        .data-table {
            font-size: 14px;
        }
    }

   

        /*footer*/
        footer {
            text-align: center;
            padding: 20px 40px;
            background-color: #333;
            color: #FFFFFF;
            border-top: 4px solid #eb9b4b;
            
        }
        </style>
<body>
     <?php if (isset($_GET['status']) && isset($_GET['message'])): ?>
        <script>
            alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>
    <header>
    <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
    </div>
    <nav>
    	<ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="KIds.php">For Kids</a></li>
                <li><a href="Adults.php">For Adults</a></li>
                <li><a href="help.php">Help</a></li>
                <li><a href="dashboard.php">My Dashboard</a></li>
                <li><a href="edit_user.php">Edit Profile</a></li>
                <li>
                <?php
                
                if ($_SESSION['is_admin'] == 1){
                	echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                }?>
                </li>
                
              
        </ul>
        <div class="auth-buttons">
             	<a href="logout.php" class="btn">Logout</a>
        </div>
    </nav>
    </header>
    <!--Main section start-->
    <main class="main-container">
    <div class="header">
         <h1 class="page-title">Welcome back, <?php echo $user_name; ?>! &#128075</h1>
        
        <a href="add_pet.php" class="btn-primary">
            Add New Pet
        </a>        
    </div>
    <div><h1 class="page-title">Your Pets</h1></div>
    
    <div class="pet-grid">
    <?php if ($pet_result->num_rows > 0) {?>
        <?php while ($row = $pet_result->fetch_assoc()) { ?>
            <div class="pet-card">
                <?php if ($row['photo']) { ?>
                    <img src="<?php echo $row['photo']; ?>" alt="Pet Photo" class="pet-image">
                <?php } else { ?>
                    <img src="default.jpg" alt="Pet Photo" class="pet-image">
                <?php } ?>
                <div class="pet-details">
                    <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
                    <p><strong>Type:</strong> <?php echo $row['pet_type']; ?></p>
                    <p><strong>Age:</strong> <?php echo $row['age']; ?></p>
                    <p><strong>Gender:</strong> <?php echo $row['gender']; ?></p>
                    <p><strong>District:</strong> <?php echo $row['district']; ?></p>
                    <p><strong>City:</strong> <?php echo $row['city']; ?></p>
                    <p><strong>Description:</strong> <?php echo $row['description']; ?></p>
                    <p><strong>Status:</strong> 
                        <?php echo ($row['is_adopted'] == 1) ? 'Adopted' : 'Not Adopted'; ?>
                    </p>
                    <div class="pet-actions">
                        <a href="edit_pet.php?pet_id=<?php echo $row['pet_id']; ?>" class="btn-secondary">Edit</a>
                        <a href="delete_pet.php?pet_id=<?php echo $row['pet_id']; ?>" class="btn-danger" onclick="return confirm('Are you sure you want to delete this pet?');">Delete</a>
                    </div>
                </div>
            </div>
        <?php } ?>
    <?php } else { echo "<p>No pets added.</p>";} ?>
    </div>

    <h2 class="section-title">Adoption Requests for Your Pets</h2>
    
    <table class="data-table">
        <thead>
            <tr>
                <th>Pet Name</th>
                <th>Full Name</th>
                <th>District</th>
                <th>City</th>
                <th>Phone Number</th>
                <th>Confirm Request</th>
                <th>Delete Request</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($adopt_row = $adopt_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $adopt_row['pet_name']; ?></td>
                    <td><?php echo $adopt_row['full_name']; ?></td>
                    <td><?php echo $adopt_row['district']; ?></td>
                    <td><?php echo $adopt_row['city']; ?></td>
                    <td><?php echo $adopt_row['phone_number']; ?></td>
                    <td>
                         <a href="confirm_request.php?confirm_adoption=1&pet_id=<?php echo $adopt_row['pet_id'];?>&adopt_id= <?php echo $adopt_row['adopt_id'];?>" class="btn-confirm"> Confirm</a> 
                    </td>
                    <td>
                         <a href="delete_request.php?delete_request=1&adopt_id= <?php echo $adopt_row['adopt_id'];?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this request?');"> Delete</a> 
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>


    <h2 class="section-title">Confirmed Adoption Requests</h2>
    
    <table class="data-table">
        <thead>
            <tr>
                <th>Pet Name</th>
                <th>Full Name</th>
                <th>District</th>
                <th>City</th>
                <th>Phone Number</th>
                <th>Delete Request</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($confirmed_row = $confirmed_adopt_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $confirmed_row['pet_name']; ?></td>
                    <td><?php echo $confirmed_row['full_name']; ?></td>
                    <td><?php echo $confirmed_row['district']; ?></td>
                    <td><?php echo $confirmed_row['city']; ?></td>
                    <td><?php echo $confirmed_row['phone_number']; ?></td>
                    <td>
                         <a href="delete_request.php?delete_request=1&adopt_id= <?php echo $confirmed_row['adopt_id'];?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this request?');"> Delete</a> 
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</main>
    <footer>
    <p>&copy;2021 Springfield Pet Rescue. All rights reserved.
    </footer>
</body>
</html>

<?php 
$pet_stmt->close();
$adopt_stmt->close();
$confirmed_adopt_stmt->close();
$connection->close(); 
?>

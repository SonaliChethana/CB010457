<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWS - Home</title>
    <link rel="stylesheet" href="css/index.css">
         <!-- Include Owl Carousel CSS -->
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
		<!--google footer social icon-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;  
        }
        main{
        flex-grow:1;
        }


        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }
         header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        body {
        font-family: 'Poppins', sans-serif; /* Using Google Font */
        background: url('Images/Paw.png') no-repeat center center;
        color: #333;
        }

        .container {
        width: 100%;
        max-width: 1170px;
        margin: 0 auto;
        padding: 0 15px;
        }
         .body-container {
           background: url('Images/Paw.png') no-repeat center center;

        }
        /* Welcome Hero Section */
        .welcome-hero {
            background: url('Images/Home.jpg') no-repeat center center;
            background-size: cover;
            padding: 100px 0;
            color: #5f513e;
            text-align: center;
        }    
		.quotes {
			background-size: cover;
			padding: 60px 0;
			color: #fff;
			text-align: center;
		}
          /* Welcome Hero Section */
        .welcome-hero .header-text {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .welcome-hero h2 {
            font-size: 4.5em;
            font-weight: 700;
            line-height: 1.4;
            margin-bottom: 10px;
            font-family: cursive;
        }
        
        .welcome-hero h2 span {
            color: #f18c28;
        }
        
        .welcome-hero p {
            font-size: 1.3em;
            line-height: 1.0;
        }
  
        /* About Section */
        .about {
        padding: 30px 80px;
        margin: 50px;
        background-color: #f5f5f5;
        }

        .section-heading {
        margin-bottom: 50px;
        }

        .section-heading h2 {
        font-size: 36px;
        font-weight: 700;
        text-align: center;
        color: #333;
        position: relative;
        display: inline-block;
        padding-bottom: 10px;
        width: 100%;
        }

        .section-heading h2::after {
        content: '';
        width: 50px;
        height: 3px;
        background-color: #27ae60;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        }

        .about-content {
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        }

        .about-txt {
        flex: 0 0 60%;
        margin-bottom: 30px;
        text-align: center;
        }

        .about-txt h3 {
        font-size: 24px;
        font-weight: 600;
        margin-bottom: 20px;
        text-align: center;
        }

        .about-txt p {
        font-size: 16px;
        line-height: 1.6;
        color: #555;
        margin-bottom: 30px;
        }

        /* Adopt Me Section */
        .section-2 {
            text-align: center;
            padding: 60px;
            background: rgba(0, 0, 0, 0.5);

        }

        .section-2 h2 {
            font-size: 40px;
            margin: 0 0 20px;
            color: #FFFFFF;
        }

        .section-2 .pet-listings {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .section-2 .card {
            background-color: #FFFFFF;
            padding: 20px;
            margin: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            transition: transform 0.3s, box-shadow 0.3s, background-color 0.3s;
            width: 400px;
            height: 600px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .section-2 .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            background-color: #ffebd8;
        }

        .section-2 .card img {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-radius: 12px;
        }

        .section-2 .card h3 {
            margin: 15px 0 10px;
            font-size: 20px;
            color: #388E3C;
        }

        .section-2 .card p {
            font-size: 17px;
            color: #616161;
        }

        .section-2 .card .adopt-btn {
            margin: 10px 0 5px;
            padding: 10px 20px;
            background-color: #c96e0c;
            color: #FFFFFF;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .section-2 .card .adopt-btn:hover {
            background-color: #FF5733;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }


        .popup-form {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1;
        }

        .popup-form .form-container {
            position: relative;
            top: 150px;
            background-color: #FFFFFF;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            width: 100%;
            margin: auto;
        }

        .popup-form h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #c96e0c;
        }

        .popup-form .form-container {
            margin-bottom: 20px;
        }

        .popup-form .form-container label {
            display: block;
            font-size: 16px;
            margin-bottom: 5px;
            color: #616161;
        }

        .popup-form .form-container input[type="text"],
        .popup-form .form-container input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin:0 0 15px;
            border: 1px solid #CCC;
            border-radius: 8px;
            font-size: 16px;
        }

        .popup-form .form-container input[type="text"]:focus,
        .popup-form .form-container input[type="tel"]:focus {
            margin:0 0 15px;  
            border-color: #4CAF50;
        }

        .popup-form .form-container button {
            width: 100%;
            padding: 12px;
            margin:20px 0 0;
            background-color: #c96e0c;
            color: #FFFFFF;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .popup-form .form-container button:hover {
            background-color: #FF5733;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .popup-form .close-btn {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 18px;
            color: #616161;
            cursor: pointer;
        }

    
        /* Service Section */
        .service_section {
        padding: 20px 0;
        background-color: #f8c68e;
        }
        
        .heading_container {
        margin-bottom: 30px;
        }
        
        .heading_container h2 {
        font-size: 36px;
        font-weight: 700;
        text-align: center;
        color: #333;
        position: relative;
        display: inline-block;
        padding-bottom: 10px;
        }
        
        .heading_container p {
        font-size: 20px;
        text-align: center;
        margin: 20px auto;
        color: #666;
        }
        
        .service_container {
        position: relative;
        }
        
        .carousel-wrap {
        position: relative;
        }
        
        .service_owl-carousel .item {
        padding: 15px;
        transition: transform 0.3s ease-in-out;
        }
        
        .service_owl-carousel .item:hover {
        transform: translateY(-10px);
        }
        
        .box {
        background-color: #f9f9f9;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        
        .box:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        
        .img-box {
        text-align: center;
        margin-bottom: 20px;
        }
        
        .img-box img {
        max-width: 100%;
        border-radius: 10px;
        }
        
        .detail-box {
        text-align: center;
        }
        
        .detail-box h5 {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 15px;
        color: #333;
        }
        
        .detail-box p {
        font-size: 14px;
        color: #666;
        }
        
        .btn-box {
        text-align: center;
        margin-top: 30px;
        }
        
        .btn-box a {
        display: inline-block;
        padding: 10px 30px;
        background-color: #27ae60;
        color: #fff;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s ease-in-out;
        }
        
        .btn-box a:hover {
        background-color: #1e8449;
        }
        
        /* Animation */
        @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
        }
        
        .service_section .box {
        animation: fadeInUp 0.6s ease-in-out both;
        }

    /* Quotes Section */

        .quotes .section-heading h2 {
        font-size: 36px;
        margin-bottom: 40px;
        font-family: cursive;
        }

        .quote-carousel .quote-item {
        font-size: 24px;
        font-family: cursive;
        margin: 0 auto;
        max-width: 600px;
        padding: 20px;
        background:  rgba(0, 0, 0, 0.5);
            color: #fff;
        border-radius: 10px solid;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        
        /* Footer */
        .footer {
        background: #333;
        color: #fff;
        padding: 30px 0;
        text-align: center;
        }

        .footer .container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        }

        .footer .container div {
        flex: 1;
        padding: 10px;
        }

        .footer h3 {
        margin-bottom: 20px;
        }

        .footer ul {
        list-style: none;
        padding: 0;
        }

        .footer ul li {
        margin-bottom: 10px;
        }

        .footer ul li a {
        color: #fff;
        text-decoration: none;
        }

        .footer ul li a:hover {
        text-decoration: underline;
        }

        .social-icons {
        display: flex;
        gap: 10px;
        }

        .social-icons a {
        font-size: 24px;
        color: #333;
        text-decoration: none;
        }

        .social-icons a:hover {
        color: #0077b5; /* Change color on hover */
        }

        .footer-bottom {
        margin-top: 20px;
        border-top: 1px solid #555;
        padding-top: 10px;
        }
	</style>
<body>
    
    <?php if (isset($_GET['status']) && isset($_GET['message'])): ?>
        <script>
            alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>

    
    <header>
       <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
        </div>
        <nav>
          <ul class="menu">
              <li><a href="index.php">Home</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="WhatWeDo.php">What we do</a></li>
              <li><a href="Kids.php">For Kids</a></li>

              <li><a href="help.php">Help</a></li>
              <li>
                  <?php if (isset($_SESSION['user_name'])){ 
                      echo '<a href="dashboard.php">My Dashboard</a>';
                  }?>
              </li>
              <li>
                  <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                      echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                  } ?>
              </li>
          </ul>
          <div class="auth-buttons">
              <?php if (isset($_SESSION['user_name'])): ?>
                  <a href="logout.php" class="btn">Logout</a>
              <?php else: ?>
                  <a href="register.php" class="btn">Register</a>
                  <a href="login.php" class="btn">Log In</a>
              <?php endif; ?>
          </div>
      </nav>
    </header>

    
  <!--welcome-hero start -->
  <section id="welcome-hero" class="welcome-hero">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center">
							<div class="header-text">
								<h2>Hi <span>,</span> Welcome to <br>Springfield Pet Rescue <span>.</span></h2>
								<p>Join us in making a difference in the lives of stray dogs through rescue, rehabilitation, and rehoming.</p>
							</div>
						</div>
					</div>
				</div>

			</section><!--/.welcome-hero-->
			<!--welcome-hero end -->

		 <!-- About Section -->
		 <section class="about" id="about">
            <div class="container">
                <div class="section-heading">
                    <h2>About Us</h2>
                </div>
                <div class="about-content">
                    <div class="about-txt">
                        <h3>Our Mission</h3>
                        <p>We are dedicated to rescuing, rehabilitating, and rehoming abandoned and stray pets. Our mission is to provide a safe haven for these animals and find them loving forever homes. We also focus on educating the community about responsible pet ownership.</p>
                    </div>
                </div>
            </div>
        </section>

        <!--Adopt section-->
      <section class="section-2">
        <h2>Adopt Me!</h2>
        <div class="pet-listings">
            <?php include 'fetch_pets.php'; ?>
        </div>
      </section>

 
		<!-- service section -->
	<section class="service_section ">
        <div class="container">
        <div class="heading_container">
            <h2>Making a Difference</h2>
          <p class="col-lg-8 px-0">Discover how Springfield Pet Rescue is dedicated to improving the lives of pets and the community.</p>
        </div>
        <div class="service_container">
          <div class="carousel-wrap ">
            <div class="service_owl-carousel owl-carousel">
                <div class="item">
              <div class="box">
                <div class="img-box">
                  <img src="images/Adoption.jpg" alt="Pet Adoption" />
                </div>
                <div class="detail-box">
                  <h5>Adoption</h5>
                  <p>Springfield Pet Rescue rehomes pets in the Western Province of Sri Lanka. They offer a variety of pets for adoption, including dogs, cats, and small animals.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="box">
                <div class="img-box">
                  <img src="images/petcare.jpg" alt="Pet care" />
                </div>
                <div class="detail-box">
                  <h5>Pet care</h5>
                  <p>Ensure pets have a balanced diet, regular healthcare, exercise, and a safe environment for their well-being.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="box">
                <div class="img-box">
                  <img src="images/community.jpeg" alt="Community" />
                </div>
                <div class="detail-box">
                  <h5>Community Engagement</h5>
                  <p>Get involved through donations, sponsored events, volunteer programs, and corporate partnerships to support Springfield Pet Rescue.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="box">
                <div class="img-box">
                  <img src="images/Children.jpg" alt="For children" />
                </div>
                <div class="detail-box">
                  <h5>Guidelines for kids</h5>
                  <p>Teach children the basics of feeding, exercising, and caring for pets with kindness and responsibility.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="box">
                <div class="img-box">
                  <img src="images/Adult care.jpg" alt="For adults" />
                </div>
                <div class="detail-box">
                  <h5>Guidelines for Adults</h5>
                  <p>Understand the long-term commitment, responsibilities, and compatibility factors involved in adopting a pet.</p>
                </div>
              </div>
            </div>
          </div>		  
      </section>
      <!-- service section ends -->  
	   
	  <!-- Quotes Section -->
		<section class="quotes" id="quotes">
			<div class="container">
				<div class="section-heading">
					<h2>Quotes</h2>
				</div>
				<div class="quote-carousel owl-carousel">
					<div class="quote-item">
						<p>"The greatness of a nation and its moral progress can be judged by the way its animals are treated." – Mahatma Gandhi</p>
					</div>
					<div class="quote-item">
						<p>"Until one has loved an animal, a part of one's soul remains unawakened." – Anatole France</p>
					</div>
					<div class="quote-item">
						<p>"Animals are such agreeable friends—they ask no questions; they pass no criticisms." – George Eliot</p>
					</div>
				</div>
			</div>
		</section>
		<!-- Quotes Section End -->
		


		
					<!--footer area-->
		   <!-- Footer Start -->
		   <footer class="footer">
			<div class="container">
				<div>
					<h3>Quick Links</h3>					
				</div>
				<div>
					<h3>Contact Us</h3>
					<ul>
						<li>Email: info@springfieldpetrescue.org</li>
						<li>Phone: +1 234 567 890</li>
						<li>Address: 123 Springfield Road, Western Province, Sri Lanka</li>
					</ul>
				</div>
				<div>
					<h3>Follow Us</h3>
					<div class="social-icons">
						<a href="https://www.facebook.com" target="_blank" class="fab fa-facebook"></a>
						<a href="https://www.twitter.com" target="_blank" class="fab fa-twitter"></a>
						<a href="https://www.instagram.com" target="_blank" class="fab fa-instagram"></a>
						<a href="https://www.linkedin.com" target="_blank" class="fab fa-linkedin"></a>
					</div>
					
				</div>
			</div>
			<div class="footer-bottom">
				© 2021 Springfield Pet Rescue. All rights reserved.
			</div>
		</footer>
		<!-- Footer End -->

		    <!-- Include Font Awesome for social icons -->
    		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
			<!-- jQuery (Bootstrap's JavaScript plugins for service section) -->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
			<!-- Include all compiled plugins (below), or include individual files as needed -->
			<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
			<!-- Bootstrap JS -->
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script>
$(document).ready(function(){
  $('.service_owl-carousel').owlCarousel({
    loop: true,
    margin: 30,
    nav: true,
    dots: false,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 3
      }
    }
  });
});
</script>
<script>
	$(document).ready(function(){
    $('.quote-carousel').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        items: 1
    });
});

</script>

        
<div id="adopt-form-popup" class="popup-form">
        <div class="form-container">
            <span id="close-popup" class="close-btn">&times;</span>
            <h2>Adoption Form</h2>
            <form id="adoptForm" action="submit_adopt.php" method="POST">
                <input type="hidden" id="pet_id" name="pet_id" />
                <label for="full_name">Full Name:</label>
                <input type="text" id="full_name" name="full_name" required />
                <label for="district">District:</label>
                <input type="text" id="district" name="district" required />
                <label for="city">City:</label>
                <input type="text" id="city" name="city" required />
                <label for="phone_number">Phone Number:</label>
                <input type="text" id="phone_number" name="phone_number" required />
                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
  

    <script src="js/index.js"></script>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user_name']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_GET['answer_id'])) {
    $answer_id = $_GET['answer_id'];
    $result = $connection->query("SELECT * FROM answers WHERE answer_id = $answer_id");
    $answer = $result->fetch_assoc();
}

if (isset($_POST['update_answer'])) {
    $question = $connection->real_escape_string($_POST['question']);
    $answer = $connection->real_escape_string($_POST['answer']);

    $query = "UPDATE answers SET question='$question', answer='$answer' WHERE answer_id=$answer_id";
    if ($connection->query($query) === TRUE) {
        header("Location: admin_dashboard.php?status=success&message=Question updated successfully.");
        exit();
    } else {
        header("Location: admin_dashboard.php?status=error&message=Error updating question: " . $connection->error);
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Question</title>
</head>
<body>
    <h1>Edit Question</h1>
    <form action="edit_answer_admin.php?answer_id=<?php echo $answer_id; ?>" method="POST">
        <input type="text" name="question" value="<?php echo htmlspecialchars($answer['question']); ?>" required>
        <textarea name="answer"><?php echo htmlspecialchars($answer['answer']); ?></textarea>
        <button type="submit" name="update_answer" class="btn-primary">Update Question</button>
    </form>
</body>
</html>

<?php $connection->close(); ?>
